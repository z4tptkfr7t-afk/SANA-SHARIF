# Sana Sharif — Academic Website (November 2026 review edition)

Static HTML/CSS/JavaScript website. All files and `assets/` must remain together.

## Publishing
1. Extract this ZIP, verify `index.html` is in the top-level folder.
2. Preview `index.html` locally in a browser.
3. GitHub Pages: create public repository `YOURUSERNAME.github.io`, upload all site files to root; under Settings > Pages, choose Deploy from a branch: main /(root).
4. Or Netlify: visit https://app.netlify.com/drop and drag the folder containing index.html.
5. Check deployment and links on a mobile browser.

## Final review notes
- IEEE WIE officer title and several university service appointment dates are still unverified; marked plainly on the public page.
- Current graduate assistant appointment end date should be confirmed.
- Paper recognition based only on an infographic is not claimed as a verified ranking.
- 2026 OJCOMS citation includes verified title/DOI and provisional author summary `et al.` pending final full metadata check.
- Website displays selected publications, not a complete bibliography.
- No student contact details or engineer registration numbers are published.
